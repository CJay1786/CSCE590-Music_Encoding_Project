clc, clear;

% Check properties of sound file
audioInfo = audioinfo("DrumLoopImageSpliceV3.wav");

% Import audio file
[y, Fs] = audioread("DrumLoopImageSpliceV3.wav");
x = y;

% Assuming watermark image size is constant
% Image size 32x32 w/ 1024 bytes gives 8192 bits
bitTotal = 8192;
yElnum = numel(y);
origElnum = yElnum - bitTotal;

byteStep = floor((origElnum+(origElnum*0.1)) / bitTotal);
bitStep = byteStep - (round(byteStep*0.1));

origElnumOffset = floor(origElnum * 0.01);
nextBitPlace = origElnum - origElnumOffset + bitTotal;

z = char(zeros(bitTotal/8, 8));

for v = 1:(bitTotal/8)
    for w = 1:8
        bit = y(nextBitPlace,1);
        prevPlace = y(nextBitPlace-1);
        nextPlace = y(nextBitPlace+1);
        if bit == nextPlace
            disp('0');
            bit = '0';
        elseif bit == prevPlace
            disp('1');
            bit = '1';
        else
            disp('NA');
            prevCopy = prevPlace;
            bitCopy = bit;
            bit = '0';
        end
        z(v,w) = bit;

        if w == 8
            nextBitPlace = nextBitPlace - (byteStep + 1);
        else
            nextBitPlace = nextBitPlace - (bitStep + 1);
        end
    end
end

z2 = bin2dec(z);
z3 = uint8(reshape(z2, 32, []));
imwrite(z3, "WatermarkImageExtracted.jpg");
imageInfo2 = imfinfo("WatermarkImageExtracted.jpg");
imageInfo3 = imfinfo("WatermarkImageGD.jpg");

% Check properties of image
imageInfo = imfinfo("WatermarkImage.jpg");

% Import image
i = imread("WatermarkImage.jpg");

% Convert image from RGB to Grayscale
i2 = rgb2gray(i);

% Downscale image to 32x32
i3 = imresize(i2, [32, 32]);

% Convert image integer values to binary characters
i4 = dec2bin(i3);