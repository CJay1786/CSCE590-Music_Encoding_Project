clc, clear;

% Check properties of sound file
audioInfo = audioinfo("DrumLoop.wav");

% Import audio file
[y, Fs] = audioread("DrumLoop.wav");
x = y;

% Check properties of image
imageInfo = imfinfo("WatermarkImage.jpg");

% Import image
i = imread("WatermarkImage.jpg");

% Convert image from RGB to Grayscale
i2 = rgb2gray(i);

% Downscale image to 32x32
i3 = imresize(i2, [32, 32]);

% Convert image integer values to binary characters
i4 = dec2bin(i3);

% Define number of elements and rows to loop thru
i4Rownum = numel(i4(:,1));
i4Elnum = numel(i4);
yElnum = numel(y);
% Offset to bring bits closer to beginning of audio
yElnumOffset = floor(yElnum * 0.01);
% Define step intervals to splice bits
step = floor(yElnum / i4Elnum);

% Add offset to step
nextStep = yElnum - yElnumOffset;
% Loop number of rows in i4 and splice 8 bits from each row
for v = 1:i4Rownum
    for w = 1:8
        bit = str2num(i4(v,w));
        if bit == 1
            bit = bit / 1000;
        end
        y = [y(1:nextStep,1); bit; y(nextStep+1:end,1)];
        nextStep = nextStep - step;
    end
end

% Write y to new audio file with spliced bits
audiowrite("DrumLoopImageSpliceV1.wav", y, Fs, "BitsPerSample", audioInfo.BitsPerSample);
adioInfo2 = audioinfo("DrumLoopImageSpliceV1.wav");
