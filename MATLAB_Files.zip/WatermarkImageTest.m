%clc, clear;

% Check properties of image
info = imfinfo("WatermarkImage.jpg");

% Import image
i = imread("WatermarkImage.jpg");

% Convert image from RGB to Grayscale
i2 = im2gray(i);
imshow(i2);

% Downscale image to 32x32
i3 = imresize(i2, [32, 32]);
imshow(i3);

% Output image
imwrite(i3, "WatermarkImageGD.jpg");
info2 = imfinfo("WatermarkImageGD.jpg");

% Convert image integer values to binary characters
i4 = dec2bin(i3);

x2 = zeros(size(y,1), 1);
x2(:, 1) = 2;
k = 572207;
x3 = [x2(1:k,1); str2num(i4(1,8)); x2(k+1:end,1)];

i4Rownum = numel(i4(:,1));
i4Elnum = numel(i4);
x2Elnum = numel(x2);
x2ElnumOffset = floor(x2Elnum * 0.01);
step = -floor(x2Elnum / i4Elnum);

nextStep = x2Elnum - x2ElnumOffset;
for v = 1:1:i4Rownum
    for w = 1:1:8
        bit = str2num(i4(v,w));
        if bit == 1
            bit = bit / 1000;
        end
        x2 = [x2(1:nextStep,1); bit; x2(nextStep+1:end,1)];
        nextStep = nextStep + step;
    end
end