clc, clear;

% Check properties of sound file
info = audioinfo("DrumLoop.wav");
disp(info.BitsPerSample);

% Import audio file
[y, Fs] = audioread("DrumLoop.wav");
[m, Ms] = audioread("DrumLoop2ChannelMono.wav");

% Plot waveform of audio file
plot(y);
title("Original Audio");

% Play audio using its samplerate
p = audioplayer(y, Fs);
%play(p);

x = zeros(size(y,1), 1);
x(:, 1) = 0.001;

z = [y, x];
audiowrite("DrumLoop2Channel.wav", z, Fs, "BitsPerSample", info.BitsPerSample);
info2 = audioinfo("DrumLoop2Channel.wav");