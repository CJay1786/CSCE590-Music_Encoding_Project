clc, clear;

% Check properties of sound file
audioInfo = audioinfo("DrumLoopImageSpliceV3PostComp.wav");

% Import audio file
[y, Fs] = audioread("DrumLoopImageSpliceV3PostComp.wav");
x = y;

% Assuming watermark image size is constant
% Image size 32x32 w/ 1024 bytes gives 8192 bits
bitTotal = 8192;
yElnum = numel(y);
origElnum = yElnum - bitTotal;

byteStep = floor((origElnum+(origElnum*0.1)) / bitTotal);
bitStep = byteStep - (round(byteStep*0.1));

origElnumOffset = floor(origElnum * 0.01);
nextBitPlace = origElnum - origElnumOffset + bitTotal;

z = char(zeros(bitTotal/8, 8));

for v = 1:(bitTotal/8)
    for w = 1:8
        bit = y(nextBitPlace,1);
        prevPlace = y(nextBitPlace-1);
        if (bit >= 0 && prevPlace >= 0) || (bit < 0 && prevPlace < 0)
            prevPlaceDiff = abs(bit - prevPlace);
        elseif (bit >= 0 && prevPlace < 0) || (bit < 0 && prevPlace >= 0)
            prevPlaceDiff = abs(bit + prevPlace);
        end

        nextPlace = y(nextBitPlace+1);
        if (bit >= 0 && nextPlace >= 0) || (bit < 0 && nextPlace < 0)
            nextPlaceDiff = abs(bit - nextPlace);
        elseif (bit >= 0 && nextPlace < 0) || (bit < 0 && nextPlace >= 0)
            nextPlaceDiff = abs(bit + nextPlace);
        end
        
        if prevPlaceDiff < nextPlaceDiff
            fprintf('1 - %d, %d, %d, %d, PrevDiff: %d/NextDiff: %d\n', prevPlace, bit, nextPlace, nextBitPlace, prevPlaceDiff, nextPlaceDiff);
            bit = '1';
        elseif prevPlaceDiff > nextPlaceDiff
            fprintf('0 - %d, %d, %d, %d, PrevDiff: %d/NextDiff: %d\n', prevPlace, bit, nextPlace, nextBitPlace, prevPlaceDiff, nextPlaceDiff);
            bit = '0';
        elseif prevPlaceDiff == nextPlaceDiff
            fprintf('NA - %d, %d, %d, %d, PrevDiff: %d/NextDiff: %d\n', prevPlace, bit, nextPlace, nextBitPlace, prevPlaceDiff, nextPlaceDiff);
            bit = '0';
        end
        z(v,w) = bit;
		
        if w == 8
            nextBitPlace = nextBitPlace - (byteStep + 1);
        else
            nextBitPlace = nextBitPlace - (bitStep + 1);
        end
    end
end

z2 = bin2dec(z);
z3 = uint8(reshape(z2, 32, []));
imwrite(z3, "WatermarkImageExtractedPostComp.jpg");
imageInfo2 = imfinfo("WatermarkImageExtracted.jpg");
imageInfo3 = imfinfo("WatermarkImageGD.jpg");

% Check properties of image
imageInfo = imfinfo("WatermarkImage.jpg");

% Import image
i = imread("WatermarkImage.jpg");

% Convert image from RGB to Grayscale
i2 = rgb2gray(i);

% Downscale image to 32x32
i3 = imresize(i2, [32, 32]);

% Convert image integer values to binary characters
i4 = dec2bin(i3);